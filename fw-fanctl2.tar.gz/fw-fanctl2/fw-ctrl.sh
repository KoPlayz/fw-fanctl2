#!/bin/bash
sudo cp fanctl /usr/bin/fanctl
sudo chmod +x /usr/bin/fanctl
sudo sh install.sh
sudo cp ectool /usr/bin/ectool

